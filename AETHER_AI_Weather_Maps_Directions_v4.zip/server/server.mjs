import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";
import dotenv from "dotenv";

dotenv.config();
const app=express();
const port=process.env.PORT||3000;
const client=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null;
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(__dirname,"..");
app.use(express.json({limit:"64kb"}));
app.use(express.static(root));

app.post("/api/ai",async(req,res)=>{
  if(!client)return res.status(503).json({error:"AETHER_AI_NOT_CONFIGURED"});
  try{
    const {message,language,weather}=req.body||{};
    if(!message)return res.status(400).json({error:"Message required"});
    const weatherContext=weather?`\nCurrent selected weather: ${JSON.stringify(weather)}`:"";
    const response=await client.responses.create({
      model:process.env.OPENAI_MODEL||"gpt-5.6-luna",
      instructions:`You are Aether AI, the friendly multilingual assistant inside the AETHER Weather app. Answer accurately and naturally. If a current weather question needs live data, rely on the supplied weather context rather than inventing weather. Reply in the user's requested language when possible (${language||"auto"}). Keep voice answers concise unless the user asks for detail.${weatherContext}`,
      input:message
    });
    res.json({answer:response.output_text||"I could not generate an answer."});
  }catch(err){res.status(500).json({error:"AI request failed"});}
});
app.listen(port,()=>console.log(`AETHER AI running at http://localhost:${port}`));
